﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using NPoco;

namespace Erp.Data
{
    public class ErpModule : Entity<ErpModule>
    {
        [Column]
        public string Name
        {
            get => this.DbGet(() => ""); set => this.DbSet(value);
        }

        public Assembly GetAssembly()
        {
            var assembly = AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault(a => a.GetName().Name == Name);
            if (assembly != null) return assembly;

            var name = AppDomain.CurrentDomain.BaseDirectory + Name + ".dll";
            return File.Exists(name) ? Assembly.LoadFile(name) : null;
        }
    }
}
