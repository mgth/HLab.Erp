using System.ComponentModel;
using Erp.Base;
using Erp.Notify;
using NPoco;

namespace Erp.Data
{
    [ExplicitColumns]
    public class Entity : IEntity
    {
        [Column]
        public int Id
        {
            get => this.DbGetId();
            set => this.DbSetId(value);
        }
        public event PropertyChangedEventHandler PropertyChanged
        {
            add => this.Add(value);
            remove => this.Remove(value);
        }

        protected SuspenderToken Token;

        public Entity()
        {
            var proxy = this.GetProxy();
            if (!proxy.HasNotifier)
            {
                proxy.SetNotifier(EntityService.D.GetOrAddHelper(GetType(), -1));
            }

            Token = this.Suspend();
        }

        public virtual void OnLoaded()
        {
            if(GetType().Name== "TarifFournisseur")
            { }
            IsLoaded = true;
            Token?.Dispose();
            Token = null;
        }

        [Ignore]
        public bool IsLoaded { get; set; }
    }
}