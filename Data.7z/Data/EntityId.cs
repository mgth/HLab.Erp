﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace Erp.Data
{
    public abstract class EntityId
    {
        protected EntityId(int id)
        {
            Id = id;
        }
        public static implicit operator int(EntityId id)
        {
            return id.Id;
        }

        public abstract Type BaseType { get; }
        public int Id { get; }
    }

    public class EntityId<T> : EntityId// Integer
        where T : IEntity
    {
        public EntityId(int id) : base(id)
        {
        }

        public override bool Equals(object other)
        {
            if (other is int)
                return Id == (int) other;

            var id = other as EntityId<T>;
            return id?.Id == Id;
        }

        public override int GetHashCode()
        {
            return Id;
        }

        public override Type BaseType => typeof(T);
    }
}
