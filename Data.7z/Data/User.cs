﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NPoco;

namespace Erp.Data
{
    [TableName("utilisateur")]
    public class User : Entity<User>
    {
        [Column("Nom")]
        public string Name
        {
            get => this.DbGet(() => ""); set => this.DbSet(value);
        }

        [Column("Prenom")]
        public string FirstName
        {
            get => this.DbGet(() => ""); set => this.DbSet(value);
        }

        [Column("Initiales")]
        public string Initials
        {
            get => this.DbGet(() => ""); set => this.DbSet(value);
        }

        [Column("Identifiant")]
        public string Login
        {
            get => this.DbGet(() => ""); set => this.DbSet(value);
        }

        [Column("MotDePasse")]
        public string CryptedPassword
        {
            get => this.DbGet(() => ""); set => this.DbSet(value);
        }

        [Column("DroitId")]
        public int? RightId
        {
            get => this.DbGet(()=>(int?)null); set => this.DbSet(value);
        }

        [Column("Fonction")]
        public string Function
        {
            get => this.DbGet(() => ""); set => this.DbSet(value);
        }
    }
}
