using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Erp.Base;
using Erp.Notify;

namespace Erp.Data
{
    class EntityService : Singleton<EntityService>
    {
        private readonly object _lockClassCache = new object();

        private readonly Dictionary<Type, EntityCache> _classCache 
            = new Dictionary<Type, EntityCache>();


        public EntityCache GetClassCache(Type type)
        {
            lock (_lockClassCache)
            {
                if (_classCache.ContainsKey(type)) return _classCache[type];
                var cache = new EntityCache(type);
                _classCache[type] = cache;
                return cache;
            }
        }


        public bool SetHelperId(IEntity entity, int id)
        {
            var proxy = entity.GetProxy();

            var notifier = proxy.Notifier;
            var helper = notifier as EntityHelper;
            if (helper?.Id == id) return false;

            var newhelper = GetOrAddHelper(entity.GetType(), id);
            newhelper.MoveEntriesFrom(notifier);
            proxy.SetNotifier(newhelper,false);
            return true;
        }

        public EntityHelper GetOrAddHelper(Type type, int id)
        {
            return GetClassCache(type).GetOrAddHelper(id);
        }

        public EntityHelper GetExistingHelper(Type type, int id)
        {
            return GetClassCache(type).GetExistingHelper(id);
        }

        public void DropCache(Type type, int? id)
        {
            var cache = GetClassCache(type);
            cache.DropCache(id);
        }

    }
}