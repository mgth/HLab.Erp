﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Erp.Data
{
    class DataList<T> : IReadOnlyList<T>
    {
        private IReadOnlyList<T> _readOnlyListImplementation;
        public IEnumerator<T> GetEnumerator()
        {
            return _readOnlyListImplementation.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return ((IEnumerable) _readOnlyListImplementation).GetEnumerator();
        }

        public int Count => _readOnlyListImplementation.Count;

        public T this[int index] => _readOnlyListImplementation[index];
    }
}
