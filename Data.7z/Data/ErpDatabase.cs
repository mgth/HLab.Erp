﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NPoco;

namespace Erp.Data
{
    class ErpDatabase : Database
    {
        public ErpDatabase(DbConnection connection) : base(connection)
        {
        }

        public ErpDatabase(DbConnection connection, DatabaseType dbType) : base(connection, dbType)
        {
        }

        public ErpDatabase(DbConnection connection, DatabaseType dbType, IsolationLevel? isolationLevel) : base(connection, dbType, isolationLevel)
        {
        }

        public ErpDatabase(DbConnection connection, DatabaseType dbType, IsolationLevel? isolationLevel, bool enableAutoSelect) : base(connection, dbType, isolationLevel, enableAutoSelect)
        {
        }

        public ErpDatabase(string connectionString, string providerName) : base(connectionString, providerName)
        {
        }

        public ErpDatabase(string connectionString, string providerName, IsolationLevel isolationLevel) : base(connectionString, providerName, isolationLevel)
        {
        }

        public ErpDatabase(string connectionString, string providerName, bool enableAutoSelect) : base(connectionString, providerName, enableAutoSelect)
        {
        }

        public ErpDatabase(string connectionString, string providerName, IsolationLevel? isolationLevel, bool enableAutoSelect) : base(connectionString, providerName, isolationLevel, enableAutoSelect)
        {
        }

        public ErpDatabase(string connectionString, DatabaseType dbType) : base(connectionString, dbType)
        {
        }

        public ErpDatabase(string connectionString, DatabaseType dbType, IsolationLevel? isolationLevel) : base(connectionString, dbType, isolationLevel)
        {
        }

        public ErpDatabase(string connectionString, DatabaseType dbType, IsolationLevel? isolationLevel, bool enableAutoSelect) : base(connectionString, dbType, isolationLevel, enableAutoSelect)
        {
        }

        public ErpDatabase(string connectionString, DatabaseType databaseType, DbProviderFactory provider) : base(connectionString, databaseType, provider)
        {
        }

        public ErpDatabase(string connectionString, DatabaseType databaseType, DbProviderFactory provider, IsolationLevel? isolationLevel = null, bool enableAutoSelect = true) : base(connectionString, databaseType, provider, isolationLevel, enableAutoSelect)
        {
        }

        public ErpDatabase(string connectionStringName) : base(connectionStringName)
        {
        }

        public ErpDatabase(string connectionStringName, IsolationLevel isolationLevel) : base(connectionStringName, isolationLevel)
        {
        }

        public ErpDatabase(string connectionStringName, bool enableAutoSelect) : base(connectionStringName, enableAutoSelect)
        {
        }

        public ErpDatabase(string connectionStringName, IsolationLevel? isolationLevel, bool enableAutoSelect) : base(connectionStringName, isolationLevel, enableAutoSelect)
        {
        }

    }
}
