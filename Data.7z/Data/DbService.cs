﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SQLite;
using System.Data.SQLite.Linq;
using System.Diagnostics;
using System.Linq.Expressions;
using System.Windows.Media.Animation;
using Erp.Base;
using Microsoft.Win32;
using MySql.Data.MySqlClient;
using NPoco;
using NPoco.Linq;

namespace Erp.Data
{
    //public abstract class  ErpContext : DbContext
    //{
    //    public ErpContext()
    //    : base(DbService.D.GetConnection(), false)
    //    {
    //        this.Configuration.LazyLoadingEnabled = false;
    //    }
    //    protected override void OnModelCreating(DbModelBuilder modelBuilder)
    //    {
    //        var initializer =
    //            new SQLite.CodeFirst.SqliteCreateDatabaseIfNotExists<ErpContext>(modelBuilder);
    //        Database.SetInitializer(initializer);

    //        base.OnModelCreating(modelBuilder);
    //    }




    //    //        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    //    //        {
    //    //            //optionsBuilder.EnableSensitiveDataLogging();
    //    //            //MultipleActiveResultSets=True;
    //    //#if LOCALSQL
    //    //    //optionsBuilder.UseMySql("server = localhost; user id = root; password = maudpace; persistsecurityinfo = True; database = lims; Convert Zero Datetime = True; ");
    //    //    optionsBuilder.UseMySql("server = localhost; user id = root; password = maudpace; persistsecurityinfo = True; database = limsmonographies; Convert Zero Datetime = True; ");
    //    //#else
    //    //            //optionsBuilder.UseMySQL("server = localhost; user id = root; password = maudpace; persistsecurityinfo = True; database = echantillonage; Convert Zero Datetime = True; ");
    //    //            //optionsBuilder.UseMySql("server = localhost; user id = root; password = maudpace; persistsecurityinfo = True; database = echantillonage; Convert Zero Datetime = True; ");
    //    //            //optionsBuilder.UseNpgsql("server = localhost; user id = root; password = maudpace;");
    //    //            //optionsBuilder..UseMySql("server = 192.168.2.3; user id = fabien; password = maudpace; persistsecurityinfo = True; database = limsmonographies; Convert Zero Datetime = True; ");
    //    //#endif

    //    //            optionsBuilder.UseSqlite("Data Source=echantillonage.db;");
    //    //            base.OnConfiguring(optionsBuilder);
    //    //        }
    //    public void Migrate()
    //    {
    //        //this.Database..Migrate();
    //    }

    //}

    public class DbService : Singleton<DbService>
    {
        public static T Add<T>(Action<T> setter, Action<T> added = null)
            where T : class, IEntity, new()
        {
            T t = new T();
            setter?.Invoke(t);

            object e = null;
            using (var db = D.Get())
            {
                e = db.Insert(t);                
            }

            if (e != null) added?.Invoke(t);

            return t;
        }
        public static int Delete<T>(IEntity<T> entity, Action<T> deleted = null)
            where T : class, IEntity<T>, new()
        {
            int result = 0;
            using (var db = D.Get())
            {
                try
                {
                    result = db.Delete<T>(entity);
                }
                catch (MySqlException)
                {
                }
            }

            if (result > 0) deleted?.Invoke((T)entity);

            return result;
        }
        public static T GetOrAdd<T>(Expression<Func<T, bool>> getter, Action<T> setter, Action<T> added = null)
            where T : class, IEntity, new()
        {
            T t;
            using (var db = D.Get())
            {
                t = db.Query<T>().FirstOrDefault(getter);
            }
            return t ?? Add(setter, added);
        }
        //public static IQueryProviderWithIncludes<T> Query<T>() => D.Get().Query<T>();
        public static List<T> Fetch<T>()
        {
            using(var db = D.Get())
                return db.Fetch<T>();
        }

        public static void Execute(Action<IDatabase> action)
        {
            using (var db = DbService.D.Get())
            {
                action(db);
            }
        }

        public static List<T> Fetch<T>(Func<IDatabase,List<T>> f, bool activate = true)
            where T : class, IEntity, new()
        {
            using (var db = DbService.D.Get())
            {
                var list = f(db);
                if (activate) list.Onloaded();
                return list;
            }
        }
        public static List<T> FetchQuery<T>(Func<IQueryProvider<T>, IQueryProvider<T>> q, bool activate = true)
            where T : class, IEntity, new()
        {
            return Fetch(db => q(db.Query<T>()).ToList(), activate);
        }
        public static List<T> FetchWhere<T>(Expression<Func<T, bool>> expression, bool activate = true)
            where T : class, IEntity, new()
        {
            return Fetch(db => db.Query<T>().Where(expression).ToList(),activate);
        }

        public static T FetchOne<T>(Expression<Func<T, bool>> expression, bool activate=true)
            where T : class, IEntity, new()
        {
            using (var db = DbService.D.Get())
            {
                var result = db.Query<T>().FirstOrDefault(expression);
                if (activate) result?.OnLoaded();
                return result;
            }
        }
        public static T FetchOne<T>(int id, bool activate=true)
            where T : class, IEntity, new()
        {
            return FetchOne<T>(e => e.Id==id, activate);
        }
        public static bool Any<T>(Expression<Func<T, bool>> expression)
        {
            using (var db = DbService.D.Get())
            {
                return db.Query<T>().Any(expression);
            }
        }

        private string _connectionString;
        private string _password;
        private string _driver;
        private int _nbOpen = 0;
        private readonly object _lockOpen = new object();

        public class ErpDatabase : Database, IDisposable
        {
            public ErpDatabase():base(D._connectionString,D._driver)
            {
                lock (D._lockOpen)
                {
                    D._nbOpen++;
                    Debug.Print("Opening " + D._nbOpen);
                    if (D._nbOpen > 30)
                    {
                        
                    }
                }
            }

            protected override void  Dispose(bool disposing)
            {
                lock (D._lockOpen)
                {
                    D._nbOpen--;
                    Debug.Print("Closing "+ D._nbOpen);
                }
            }
        }

        public IDatabase Get()
        {
            var db = new ErpDatabase();
            return db;
        }

        public void Register(string registryPath)
        {
            using (var rk = Registry.CurrentUser.OpenSubKey(@"Software\" + registryPath))
            {
                if (rk == null) return;
                _connectionString = rk.GetValue("Connection").ToString();
                _driver = rk.GetValue("Driver").ToString();
            }
        }
    }
}
