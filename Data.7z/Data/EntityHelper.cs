﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
////using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Security.Cryptography.X509Certificates;
using System.Windows.Navigation;
using Erp.Notify;

namespace Erp.Data
{
    public interface IEntity : INotifyPropertyChanged
    {
        int Id{ get; set; }
        bool IsLoaded { get; set; }
        void OnLoaded();
    }
    public interface IEntity<T> : IEntity
        where T : IEntity<T>
    {
        //EntityId<T> Id { get; set; }
    }

    public class Entity<T> : Entity, IEntity<T>
        where T : Entity<T>
    {
    }


    class EntityCache
    {
        private readonly object _lockCache = new object();
        private readonly Dictionary<int, WeakReference<EntityHelper>> _cache 
            = new Dictionary<int, WeakReference<EntityHelper>>();


        private readonly Type _type;
        public EntityCache(Type type)
        {
            this._type = type;
        }
        public EntityHelper GetOrAddHelper(int id)
        {
            lock (_lockCache)
            {
                var helper = GetExistingHelper(id);
                if (helper != null) return helper;

                helper = new EntityHelper(_type, id);

                if(id>=0)
                    _cache.Add(id, new WeakReference<EntityHelper>(helper));

                return helper;
            }
        }
        public EntityHelper GetExistingHelper(int id)
        {
            lock (_lockCache)
            {
                if (id >= 0 && _cache.ContainsKey(id))
                {
                    var w = _cache[id];
                    if (w.TryGetTarget(out EntityHelper target)) return target;
                    _cache.Remove(id);
                }

                return null;
            }
        }

        public void DropCache(int? id)
        {
            if (id == null) return;
            lock (_lockCache)
            {
                if (_cache.ContainsKey(id.Value))
                {
                    _cache.Remove(id.Value);
                }
                else throw new Exception("Entity not found in cache");                
            }
        }
    }


    public class EntityHelper : Notifier
    {
        public int Id { get; }
 


        public EntityHelper(Type type, int id) : base(type)
        {
            Id = id;
        }




        public bool AutoSave = false;

        public bool HasChanged => true;
    }




    public interface IOrderedEntity
    {
        int? Order { get; set; }
    }

    public static class OrderedEntityNotifierExt
    {
        public static void PlaceLast<T>(this T entity, IEnumerable<T> db) where T : class, IOrderedEntity
        {
            entity.Order = (db.Max(x => x.Order) ?? -1) + 1;
        }
        public static void PlaceAt<T>(this IOrderedEntity entity, IEnumerable<T> db, int position) where T : class, IOrderedEntity
        {
            entity.Unplace(db);
            foreach (var others in db.Where(x => x.Order >= position))
            {
                others.Order++;
            }
            entity.Order = position;
        }

        public static void Unplace<T>(this T entity, IEnumerable<T> db) where T : class, IOrderedEntity
        {
            if (entity.Order == null) return;
            int old = entity.Order.Value;
            entity.Order = null;
            foreach (var others in db.Where(x => x.Order > old))
            {
                others.Order--;
            }
        }


    }
}
