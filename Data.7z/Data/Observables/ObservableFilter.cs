﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Linq;
using System.Windows.Data;
using Erp.Notify;

namespace Erp.Data.Observables
{
    public class ObservableFilter<T> : ObservableCollectionNotifier<T>
    {
        private class Filter
        {
            public string Name { get; set; }
            public Func<T, bool> Expression { get; set; } = null;
            //public Func<IEnumerable<T>, IEnumerable<T>> Func { get; set; }
            public int Order { get; set; }
        }

        private readonly object _lockFilters = new object();
        private readonly List<Filter> _filters = new List<Filter>();

        public ObservableFilter<T> AddFilter(Func<T, bool> expr, int order = 0, string name = null)
        {
            lock (_lockFilters)
            {
                if (name != null) RemoveFilter(name);
                _filters.Add(new Filter
                {
                    Name = name,
                    Expression = expr,
                    Order = order,
                });
                return this;
            }
        }
        public ObservableFilter<T> RemoveFilter(string name)
        {
            lock (_lockFilters)
            {
                foreach (Filter f in _filters.Where(f => f.Name == name).ToList())
                {
                    _filters.Remove(f);
                }
                return this;
            }
        }


        public class CreateHelper : IDisposable
        {
            public ObservableFilter<T> List = null;
            public T ViewModel = default(T);

            public TVm GetViewModel<TVm>() where TVm:class => ViewModel as TVm;

            public bool Done = true;

            public void Dispose()
            {
            }
        }

        private INotifyCollectionChanged _list = null;
        public ObservableFilter<T> Link(INotifyCollectionChanged list)
        {
            if(_list!=null) _list.CollectionChanged -= _list_CollectionChanged;
            Debug.Assert(Count==0);

            _list = list;

            if (_list != null)
            {
                _list_CollectionChanged(null,
                    new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Add, _list as IList, 0));

                _list.CollectionChanged += _list_CollectionChanged; ;                
            }
            return this;
        }

        public ObservableFilter<T> SetObserver(NotifyCollectionChangedEventHandler handler)
        {
            lock (Lock)
            {
                handler?.Invoke(null, new NotifyCollectionChangedEventArgs(NotifyCollectionChangedAction.Add, this.ToList()));
                CollectionChanged  += handler;
            }
            return this;
        }

        public ObservableFilter()
        {
            BindingOperations.EnableCollectionSynchronization(this, Lock);
        }

        private void _list_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            switch (e.Action)
            {
                case NotifyCollectionChangedAction.Add:
                    Debug.Assert(e.NewItems != null);
                    //Debug.Assert(e.NewItems.Count == (_list as IList)?.Count - Count);
                    {
                        foreach (var item in e.NewItems.OfType<T>())
                        {
                            if (Match(item))
                            {
                                Add(item);
                            }
                        }
                    }
                     break;
                case NotifyCollectionChangedAction.Remove:

                    Debug.Assert(e.OldItems!=null);
                    {
                        foreach (var item in e.OldItems.OfType<T>())
                        {
                            lock(Lock)
                            if (Contains(item)) Remove(item);
                        }                    
                    }
                    
                    break;
                case NotifyCollectionChangedAction.Replace:
                    throw new NotImplementedException("Replace not implemented");
                case NotifyCollectionChangedAction.Move:
                    throw new NotImplementedException("Move not implemented");
                case NotifyCollectionChangedAction.Reset:
 //                       base.Clear();
                    ;
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }

            //Debug.Assert(Count == (_list as IList)?.Count);


        }

        private bool Match(T item)
        {
            if (_filters == null) return true;
            if (item != null)
            {
                return _filters.Where(filter => filter.Expression != null).All(filter => filter.Expression(item));
            }
            return false;
        }

    }
}
