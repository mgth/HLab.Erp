﻿//#define MULTITHREAD

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Linq.Expressions;
using Erp.Base.Commands;
using Erp.Notify;
using NPoco;
using NPoco.Linq;

////using System.Data.Entity;

namespace Erp.Data.Observables
{
    public interface IObservableQuery
    {
        IEntity SelectedEntity { get; set; }
        void Update();
    }

    public class ObservableQuery<T> : ObservableCollectionNotifier<T>, ITriggable, IObservableQuery
        where T : class, IEntity<T>, new()
    {
        public ModelCommand CreateCommand => this.GetCommand(Create, ()=>true);
        public ModelCommand DeleteCommand => this.GetCommand(Delete, ()=>false);

        public class CreateHelper : IDisposable
        {
            public ObservableQuery<T> List = null;
            public T Entity = null;
            public IDatabase Context { get; } = DbService.D.Get();
            public bool Done = true;

            public void Dispose()
            {
                Context?.Dispose();
            }
        }
        private class Filter
        {
            public string Name { get; set; }
            public Expression<Func<T, bool>> Expression { get; set; } = null;
            public Func<IQueryProvider<T>, IQueryProvider<T>> Func { get; set; } = null;
            public int Order { get; set; }
        }
        private class PostFilter
        {
            public string Name { get; set; }
            public Func<T, bool> Expression { get; set; } = null;
            public Func<IEnumerable<T>, IEnumerable<T>> Func { get; set; }
            public int Order { get; set; }
        }

        private readonly object _lockFilters = new object();
        private readonly List<Filter> _filters = new List<Filter>();
        private readonly List<PostFilter> _postFilters = new List<PostFilter>();

        public ObservableQuery(Func<IDatabase, IQueryProvider<T>> src)
        {
            SourceQuery = src;
        }

        public ObservableQuery()
        {
            SourceQuery = (db)=>db.Query<T>();
        }
        public ObservableQuery(Func<IEnumerable<T>> src)
        {
            SourceEnumerable = src;
        }

        public T Selected
        {
            get { lock (Lock) return this.Get<T>(); }
            set { lock (Lock) this.Set(value); }
        }

        [TriggedOn(nameof(Selected))]
        public IEntity SelectedEntity
        {
            get => this.Get(() => Selected);
            set => Selected = (T)value;
        }

        public Func<IDatabase, IQueryProvider<T>> SourceQuery
        {
            get => this.Get<Func<IDatabase, IQueryProvider<T>>>(() => null); set => this.Set(value);
        }
        public Func<IEnumerable<T>> SourceEnumerable
        {
            get => this.Get<Func<IEnumerable<T>>>(() => null); set => this.Set(value);
        }


        private IQueryProvider<T> Query(IDatabase context)
        {

                IQueryProvider<T> s = SourceQuery(context);

                if (s == null) return null;

                lock (_lockFilters)
                    foreach (Filter filter in _filters.OrderBy(f => f.Order))
                    {
                        s = filter.Func!=null ? filter.Func(s) : s.Where(filter.Expression);
                    }
                return s;
        }


        private IEnumerable<T> PostQuery(IEnumerable<T> q)
        {
            if (q == null) return null;
            lock (_lockFilters)
                foreach (var filter in _postFilters.OrderBy(f => f.Order))
                {
                    q = filter.Func != null ? filter.Func(q) : q.Where(filter.Expression);
                }
            return q;
        }
        private IEnumerable<T> PostQuery(IDatabase context)
        {
            return PostQuery(Query(context).ToEnumerable());
        }

        private List<T> PostQuery()
        {
            if(SourceEnumerable!=null)
                return PostQuery( SourceEnumerable?.Invoke() ).ToList();

            List<T> result;

            using (var context = DbService.D.Get())
            {
                // NullException : often occur when data is not nullable but sql is
                result = PostQuery(context).ToList();
            }

            return result;
        }

        public ObservableQuery<T> AddFilter(string name, Expression<Func<T, bool>> expression, int order = 0)
        {
            return AddFilter(expression, order, name);
        }

        public ObservableQuery<T> AddFilter(Expression<Func<T, bool>> expression, int order = 0, string name = null)
        {
            lock (_lockFilters)
            {
                if (name != null) RemoveFilter(name);
                _filters.Add(new Filter
                {
                    Name = name,
                    Expression = expression,
                    Order = order,
                });
                return this;
            }
        }

        public ObservableQuery<T> AddFilter(Func<IQueryProvider<T>, IQueryProvider<T>> func, int order = 1, string name = null)
        {
            lock (_lockFilters)
            {
                if (name != null) RemoveFilter(name);
                _filters.Add(new Filter
                {
                    Name = name,
                    Func = func,
                    Order = order,
                });
                return this;
            }
        }
        public ObservableQuery<T> AddPostFilter(string name, Func<T, bool> expression, int order = 0)
        {
            return AddPostFilter(expression, order, name);
        }

        public ObservableQuery<T> AddPostFilter(Func<T, bool> expression, int order = 0, string name = null)
        {
            lock (_lockFilters)
            {
                if (name != null) RemoveFilter(name);
                _postFilters.Add(new PostFilter
                {
                    Name = name,
                    Expression = expression,
                    Order = order,
                });
                return this;
            }
            //return AddPostFilter(s => s.Where(expression), order, name);
        }

        public ObservableQuery<T> AddPostFilter(Func<IEnumerable<T>, IEnumerable<T>> func, int order = 0, string name = null)
        {
            lock (_lockFilters)
            {
                if (name != null) RemovePostFilter(name);
                _postFilters.Add(new PostFilter
                {
                    Name = name,
                    Func = func,
                    Order = order,
                });
                return this;
            }
        }
        public ObservableQuery<T> RemoveFilter(string name)
        {
            lock (_lockFilters)
            {
                foreach (Filter f in _filters.Where(f => f.Name == name).ToList())
                {
                    _filters.Remove(f);
                }
                return this;
            }
        }

        public ObservableQuery<T> RemovePostFilter(string name)
        {
            lock (_lockFilters)
            {
                foreach (var f in _postFilters.Where(f => f.Name == name).ToList())
                {
                    _postFilters.Remove(f);
                }
                return this;
            }
        }

        //public Func<TThis, T, DbContext, bool> OnCreate;
        protected readonly Dictionary<string, Action<CreateHelper>> OnCreate = new Dictionary<string, Action<CreateHelper>>();
        protected readonly Dictionary<string, Action<CreateHelper>> OnCreated = new Dictionary<string, Action<CreateHelper>>();

        protected readonly Dictionary<string, Action<CreateHelper>> OnDelete = new Dictionary<string, Action<CreateHelper>>();
        protected readonly Dictionary<string, Action<CreateHelper>> OnDeleted = new Dictionary<string, Action<CreateHelper>>();
        protected void Create()
        {
            var entity = new T();

            using (var helper = new CreateHelper { List = this, Entity = entity })
                if (Exec(OnCreate, helper))
                {
                    helper.Context.Insert(entity);

                    Selected = entity;
                    FluentUpdate();
                    Exec(OnCreated, helper);
                }
        }
        protected void Delete()
        {
            var entity = Selected;
            if (entity == null) return;

            if (Exec(OnDelete, new CreateHelper
            {
                List = this,
                Entity = entity,
            }))
            {
                DbService.Execute(d => d.Delete(Selected));

                FluentUpdate();

                Exec(OnDeleted, new CreateHelper
                {
                    List = this,
                    Entity = entity,
                });
            }           
        }

        private ObservableQuery<T> AddCreator(IDictionary<string, Action<CreateHelper>> dict, Action<CreateHelper> func,
            string name = "")
        {
            lock (_lockFilters)
            {
                if (name != null && dict.ContainsKey(name)) dict.Remove(name);
                dict.Add(name ?? "", func);
                return this;
            }
        }

        protected bool Exec(Dictionary<string, Action<CreateHelper>> dict, CreateHelper h)
        {
            foreach (var action in dict.Values)
            {
                action(h);
                // if one action fail, we don't want to create new entity.
                if (!h.Done) return false;
            }
            return true;
        }

        public ObservableQuery<T> AddOnCreate(Action<CreateHelper> func, string name = "")
        {
            return AddCreator(OnCreate, func, name);
        }
        public ObservableQuery<T> AddOnCreated(Action<CreateHelper> func, string name = "")
        {
            return AddCreator(OnCreated, func, name);
        }
        public ObservableQuery<T> AddOnDelete(Action<CreateHelper> func, string name = "")
        {
            return AddCreator(OnDelete, func, name);
        }
        public ObservableQuery<T> AddOnDeleted(Action<CreateHelper> func, string name = "")
        {
            return AddCreator(OnDeleted, func, name);
        }

        public ModelCommand GetEntityInteractifCommand => this.GetCommand(GetEntityInteractif,()=>true);

        public void GetEntityInteractif()
        {
            //Selected = GetEntityInteractif(Selected);
        }

        //public T GetEntityInteractif(T item)
        //{
        //    var view = new EntitySelectorWindow { DataContext = this };

        //    if (item != null) Select(item);

        //    if (view.ShowDialog() ?? false)
        //    {
        //        var selectedItem = Selected?.Entity;
        //        //GetDbContext.Entry(selectedItem).State = EntityState.Detached;
        //        return selectedItem;
        //    }
        //    return item;
        //}





        private readonly object _lockUpdate = new object();

        public ObservableQuery<T> FluentUpdate()
        {
            //Todo : multithreading
#if MULTITHREAD
                var t = new Thread(() =>

    {
                try
                {
                    Monitor.Enter(_lockUpdateNeeded);
                    _updateNeeded = true;
                    lock (_lockUpdate)
                    {
                        Monitor.Exit(_lockUpdateNeeded);
                        UpdateThread();
                    }
                }
                finally { if(Monitor.IsEntered(_lockUpdateNeeded)) Monitor.Exit(_lockUpdateNeeded); }
            }
            );
            t.Start();
#else
            Update();
#endif
            return this;
        }

        private readonly object _lockUpdateNeeded = new object();
        private volatile bool _updateNeeded = false;


        private volatile bool _updating = false;

        public void Update()
        {
            lock (_lockUpdate)
            {
                if (_updating) return;
                _updating = true;
                _updateNeeded = false;
            }


            var changed = false;


            var n = 0;
            //using (new DebugTimer("=== FluentUpdate ==="))
            using (this.Suspend())
            {
                List<T> list = PostQuery()/*.ToList()*/;

                if (list == null) return;

                    var count = list.Count;

                    foreach (var item in list)
                    {

                        var id = item.Id;

                        if (_updateNeeded) return;
                        // while list is consistant
                        if (n < Count && id == this[n].Id)
                        {
                            n++;
                            continue;
                        }

                        //next item exists elswhere in collection
//                        var vm = this.FirstOrDefault(e => ReferenceEquals(e.GetNotifier(),item.GetNotifier()));
                    var vm = this.FirstOrDefault(e => e.Id == id);
                    if (vm != null)
                        {
                            //if item found before current position it's duplicate items 
                            Debug.Assert(IndexOf(vm) > n);


                            Remove(vm);
                            base.Insert(n, vm);

                            vm.PropertyChanged += Vm_PropertyChanged;

                            n++;
                            continue;
                        }

                        item.OnLoaded();
                        base.Insert(n, item);
                        n++;
                        changed = true;
                    }

                    //remove remaining items
                    while (n < Count)
                    {
                        var vm = this[n];
                        vm.PropertyChanged -= Vm_PropertyChanged;
                        RemoveAt(n);
                    }

                    Debug.Assert(Count==count);
                
            }

            foreach (var i in this)
            {
                Debug.Assert(this.Count(e => e.Id == i.Id) == 1);
            }

            if (!changed)
            {
            }

            _updating = false;
        }

        //take care of modified entity that do not match filters anymore
        private void Vm_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            var vm = sender as T;
            if (!Match(vm)) Remove(vm);
        }

        private bool Match(T vm)
        {
            if (vm != null)
            {
                return _filters.Where(filter => filter.Expression != null).All(filter => filter.Expression.Compile()(vm)) 
                    && _postFilters.Where(filter => filter.Expression != null).All(filter => filter.Expression(vm));
            }
            return false;
        }

        public void OnTrigged()
        {
            FluentUpdate();
        }

        public override void Add(T item)
        {
            throw new NotImplementedException("Observable Query is readOnly");
        }
        public override void Insert(int index, T item)
        {
            throw new NotImplementedException("Observable Query is readOnly");
        }
    }
}
