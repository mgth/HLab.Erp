﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Erp.Notify;

namespace Erp.Data
{
    public abstract class EntityMessage
    {
        public abstract bool IsSameOrAnotherOf(IEntity item);
    }

    public class EntityMessage<T> : EntityMessage
        where T : class , IEntity<T>
    {
        protected readonly T Entity;
        public /*EntityId<T>*/ int?  Id { get; protected set; }

        public EntityMessage(T entity)
        {
                Entity = entity;
                Id = entity.Id;
        }

        public EntityMessage(/*EntityId<T>*/int? id)
        {
            Id = id;
        }

        public bool IsAnotherOf(T entity)
        {
            return !ReferenceEquals(entity, Entity) && Equals(entity?.Id, Id);
        }
        public bool IsAnotherOf(IEntity entity)
        {
            return IsAnotherOf(entity as T);
        }
        public override bool IsSameOrAnotherOf(IEntity entity)
        {
            return Equals((entity as T)?.Id, Id);
        }
        public bool Is(IEntity entity)
        {
            return ReferenceEquals(entity, Entity);
        }
    }
}
