using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using Erp.Notify;
using NPoco;

namespace Erp.Data
{
    public static class EntityExt
    {
        public static void Onloaded(this IEnumerable<IEntity> list)
        {
            foreach (var e in list)
            {
                e?.OnLoaded();
            }
        }


        public static int DbGetId(this IEntity entity)
        {
            var proxy = entity.GetProxy();
            if (!proxy.HasNotifier) return -1;//throw new Exception("ID has not been set");

            var notifier = proxy.Notifier as EntityHelper;
            if(notifier==null)  throw new Exception("Notifier should be EntityHelper");

            var id = notifier.Id;
            //if(id==null) throw new Exception("trying to read null ID");

            return id;
        }

        public static bool DbSetId(this IEntity entity, int value)
        {
            return entity.SetHelperId(value);
        }

        public static T DbGet<TE, T>(this TE entity, [CallerMemberName] string propertyName = null)
            where TE : class, IEntity, new()
        {
            return entity.DbGet<TE,T>(a => default(T), propertyName);
        }

        public static T DbGet<TE, T>(this TE entity, Func<T> def, [CallerMemberName] string propertyName = null)
            where TE : class, IEntity, new()
        {
            return entity.DbGet<TE,T>(a => def(), propertyName);
        }

        public static T DbGetForeign<T>(this IEntity entity, int? id, [CallerMemberName] string propertyName = null)
            where T : class, IEntity, new()
        {
            return  entity.Get(() => entity.DbGetForeign2<T>(id, propertyName),propertyName);
        }

        private static T DbGetForeign2<T>(this IEntity entity, int? id, string propertyName)
            where T : class, IEntity, new()
        {
            if (id == null) return null;

            T result;

            if (entity.GetNotifier().IsSet(propertyName))
            {
                result = entity.Get<T>(propertyName);
                if (result?.Id == id) return result;
            }

            var h = EntityService.D.GetExistingHelper(typeof(T), id.Value);
            if (h != null)
            {
                result = new T()
                {
                    IsLoaded = true
                };
                result.GetProxy().SetNotifier(h);
                return result;
            }

            
            result = DbService.FetchOne<T>(id.Value);

            result?.OnLoaded();

            entity.Set(result,propertyName);

            return result;
        }


        public static NotifierProxy NotifierProxy<TE>(this TE entity)
            where TE : class, IEntity, new()
        {
            return entity.GetProxy();
        }
        //public static EntityHelper<TE> GetEntityHelper<TE>(this TE entity)
        //    where TE : class, IEntity, new()
        //{
        //    var proxy = entity.GetProxy();
        //    if (proxy.Notifier == null) proxy.Notifier = EntityHelper<TE>.GetHelper(entity);

        //    if(!(proxy.Notifier is EntityHelper<TE>)) throw new InvalidCastException();

        //    return proxy.Notifier as EntityHelper<TE>;
        //}

        public static T DbGet<TE, T>(this TE entity, Func<T, T> def, [CallerMemberName] string propertyName = null)
            where TE : class, IEntity, new()
        {
            //var proxy = entity.GetProxy();
            //if (proxy.Notifier == null) proxy.Notifier = EntityHelper<TE>.GetHelper(entity);

            return entity.NotifierProxy().Notifier.Get<T>(/*def, */propertyName);
        }

        public static bool DbSet<TE, T>(this TE entity, T value, [CallerMemberName] string propertyName = null)
            where TE : class, IEntity, new()
        {
            var proxy = entity.GetProxy();
            var notifier = proxy.Notifier as EntityHelper;

            if (notifier == null) throw new Exception("Notifier not set");


                var result = notifier.Set<T>(value,propertyName,
                    () =>
                    {
                        if (entity.IsLoaded && entity.DbGetId()>=0)
                        {
                            using (var db = DbService.D.Get())
                            {
                                var attr = entity?.GetType().GetProperty(propertyName)?.GetCustomAttribute<ColumnAttribute>();

                                var name = attr?.Name ?? propertyName;

                                db.Update(entity, new[] { name });
                            }
                        }

                    }
                );      
                
                return result;
            
        }


        public static string AnchorId<T>(this IEntity<T> entity)
            where T : IEntity<T>
        {
            if (entity == null) return null;
            return entity.GetType().Name + "_" + entity.Id;
        }
        public static bool SetHelperId(this IEntity obj, int id = -1)
        {
            return EntityService.D.SetHelperId(obj, id);
        }

        //public static T Load<T>(this IEntity entity, int id)
        //where T : class, IEntity, new()
        //{
        //    return entity.GetEntityHelper().Load<T>(id);
        //}



        public static bool IsAnotherOf(this IEntity eThis, IEntity eOther)
        {
            return !eThis.IsSameInstance(eOther) && eThis.Is(eOther);
        }

        public static bool Is(this IEntity eThis, IEntity eOther)
        {
            if (eThis.GetType() != eOther.GetType()) return false;

            return eThis.Id == eOther.Id;
        }

        public static bool IsSameInstance(this IEntity ethis, IEntity eOther)
        {
            return ReferenceEquals(eOther, ethis);
        }

    }
}