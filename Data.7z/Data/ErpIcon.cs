﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Markup;
using Erp.Notify;

namespace Erp.Data
{
    class ErpIcon : Entity<ErpIcon>
    {
        private string Name
        {
            get => this.Get<string>(); set => this.Set(value);
        }
        private byte[] IconData
        {
            get => this.Get<byte[]>(); set => this.Set(value);
        }
        private string Format
        {
            get => this.Get<string>(); set => this.Set(value);
        }
        private string ClassName
        {
            get => this.Get<string>(); set => this.Set(value);
        }


        public string Xaml => this.Get<string>(() =>
        {
            using (GZipStream stream = new GZipStream(new MemoryStream(IconData),
                CompressionMode.Decompress))
            using (var sr = new StreamReader(stream))
            {
                return sr.ReadToEnd();
            }
        });

        public UIElement IconElement => this.Get<UIElement>(() =>
        {
            using (GZipStream stream = new GZipStream(new MemoryStream(IconData),
                CompressionMode.Decompress))
            {
                return (UIElement)XamlReader.Load(stream);
            }
        });
    }
}
